from __future__ import annotations
from functools import total_ordering


@total_ordering
class Currency:
    name: str
    sign: str
    __price: float  # lebegőpontos/ valós változó

    @property  # getter /setter a módosításhoz arra jó hogy tudjam váltaztatni
    def price(self) -> float:
        return self.__price

    @price.setter
    def price(self, price):
        self.__price = price

    def __init__(self, name, sign, __price) -> None:
        self.name = name
        self.sign = sign
        self.__price = __price

    def __repr__(self) -> str:
        rep = self.name + ', ' + self.sign + ', ' + str(self.__price)
        return rep

    def __str__(self) -> str:
        # return self.sign + " (" + self.name + ") : $" + str(self.__price)
        return f'{self.name} ({self.sign}): ${str(self.__price)}'

    def __eq__(self, o: object) -> bool:
        # if isinstance(o, Currency):
        # return self.name == o.name and self.sign == o.sign and self.__price == o.__price
        # return NotImplemented
        if not isinstance(o, Currency):
            return False
        return self.name == o.name and self.sign == o.sign and self.__price == o.__price

    def __lt__(self, other):
        # if isinstance(other, Currency):
        # return self.__price < other.__price and other.name < self.name and other.sign < self.sign
        if not isinstance(self, Currency):
            return False
        return (-self.__price, self.name, self.sign) < (-other.__price, other.name, other.sign)

    @staticmethod
    def compare_currencies(currencies: list[Currency], sign: str) -> list[list[str]]:
        signs = []
        k = 0
        for i in currencies:
            if sign == i.name:
                if k < i.__price:
                    signs.append([i.name])
                    k = i.__price
        return signs


class CryptoCurrency(Currency):
    __designer_name = str

    def __init__(self, name, sign, __price, __designer_name) -> None:
        super().__init__(name, sign, __price)
        self.__designer_name = __designer_name

    @property
    def designer(self):
        return self.__designer_name

    @designer.setter
    def designer(self, d_name):
        self.__designer_name = d_name

    def __repr__(self) -> str:
        return f"{super().__repr__()}, {self.__designer_name}"

    def __str__(self) -> str:
        return f"{super().__str__()}, @{self.__designer_name}"