import sys
import model


def main() -> None:
    assert len(sys.argv) > 1

    try:
        number = int(sys.argv[1])
        list = []
        if len(sys.argv) < 1:
            return "Nincs parancssori argumentum"
        else:
            for i in range(number):
                tokens = input()
                tokens = tokens.split(";")
                if len(tokens) == 3:
                    currencys = model.Currency(tokens[0], tokens[1], float(tokens[2]))
                    list.append(currencys)
                elif len(tokens) == 4:
                    crypto = model.CryptoCurrency(tokens[0], tokens[1], float(tokens[2]), tokens[3])
                    list.append(crypto)
                else:
                    print("rossz a bemenet")
        list.sort()
        for i in list:
            print(i)

    except ValueError:
        print("A bemenet elemei nem megfeleloek")


if __name__ == "__main__":
    main()